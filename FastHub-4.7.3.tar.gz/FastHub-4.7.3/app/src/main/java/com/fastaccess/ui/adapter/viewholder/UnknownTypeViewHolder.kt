package com.fastaccess.ui.adapter.viewholder

import android.view.View
import com.fastaccess.ui.widgets.recyclerview.BaseViewHolder

/**
 * Created by kosh on 07/08/2017.
 */
class UnknownTypeViewHolder(view: View) : BaseViewHolder<Any>(view) {
    override fun bind(t: Any) {} //DO NOTHING
}