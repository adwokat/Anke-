package com.fastaccess.data.dao;

import java.util.ArrayList;

/**
 * Created by Kosh on 31 Dec 2016, 1:28 PM
 */

public class ReleasesAssetsListModel extends ArrayList<ReleasesAssetsModel> {}
